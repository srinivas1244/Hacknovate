/*
  # StoryWeaver AI Database Schema

  ## Overview
  Complete database schema for the StoryWeaver AI autonomous story generation system.
  Supports multi-agent workflow, user preferences, story versioning, and feedback learning.

  ## New Tables

  ### Core Tables
  
  1. `users`
     - `id` (uuid, primary key) - User identifier
     - `email` (text) - User email
     - `display_name` (text) - Display name
     - `created_at` (timestamptz) - Account creation timestamp
     - `updated_at` (timestamptz) - Last update timestamp

  2. `user_preferences`
     - `id` (uuid, primary key)
     - `user_id` (uuid, foreign key) - Links to users
     - `favorite_genres` (jsonb) - Array of preferred genres
     - `favorite_tones` (jsonb) - Array of preferred tones
     - `preferred_duration` (text) - Short, medium, or long
     - `visual_style` (text) - Preferred visual style
     - `updated_at` (timestamptz)

  3. `stories`
     - `id` (uuid, primary key)
     - `user_id` (uuid, foreign key) - Story creator
     - `title` (text) - Story title
     - `prompt` (text) - Original user prompt
     - `genre` (text) - Story genre
     - `tone` (text) - Story tone
     - `duration` (text) - Target duration
     - `status` (text) - generating, completed, failed
     - `created_at` (timestamptz)
     - `updated_at` (timestamptz)

  4. `story_structure`
     - `id` (uuid, primary key)
     - `story_id` (uuid, foreign key) - Links to stories
     - `exposition` (text) - Story exposition
     - `conflict` (text) - Main conflict
     - `climax` (text) - Story climax
     - `resolution` (text) - Story resolution
     - `created_at` (timestamptz)

  5. `characters`
     - `id` (uuid, primary key)
     - `story_id` (uuid, foreign key)
     - `name` (text) - Character name
     - `personality` (text) - Personality description
     - `goals` (text) - Character goals
     - `dialogue_tone` (text) - How they speak
     - `visual_description` (text) - Appearance
     - `role` (text) - protagonist, antagonist, supporting
     - `created_at` (timestamptz)

  6. `scenes`
     - `id` (uuid, primary key)
     - `story_id` (uuid, foreign key)
     - `scene_number` (integer) - Order in story
     - `title` (text) - Scene title
     - `description` (text) - Visual description
     - `location` (text) - Scene location
     - `time_of_day` (text) - Time setting
     - `mood` (text) - Scene mood
     - `dialogue` (text) - Scene dialogue
     - `visual_prompt` (text) - AI image generation prompt
     - `image_url` (text) - Generated image URL
     - `created_at` (timestamptz)

  7. `music_cues`
     - `id` (uuid, primary key)
     - `story_id` (uuid, foreign key)
     - `scene_id` (uuid, foreign key, nullable)
     - `mood` (text) - Music mood
     - `tempo` (text) - Fast, medium, slow
     - `instruments` (text) - Instrument description
     - `prompt` (text) - Music generation prompt
     - `audio_url` (text) - Generated audio URL
     - `created_at` (timestamptz)

  8. `scripts`
     - `id` (uuid, primary key)
     - `story_id` (uuid, foreign key)
     - `content` (text) - Full screenplay
     - `format` (text) - screenplay, narrative, storyboard
     - `version` (integer) - Version number
     - `created_at` (timestamptz)

  9. `feedback`
     - `id` (uuid, primary key)
     - `story_id` (uuid, foreign key)
     - `user_id` (uuid, foreign key)
     - `rating` (integer) - 1-5 rating
     - `scene_ratings` (jsonb) - Per-scene ratings
     - `liked_elements` (jsonb) - What user liked
     - `improvement_suggestions` (text) - User feedback
     - `watch_time_seconds` (integer) - Engagement metric
     - `created_at` (timestamptz)

  10. `agent_logs`
      - `id` (uuid, primary key)
      - `story_id` (uuid, foreign key)
      - `agent_name` (text) - Which agent ran
      - `input_data` (jsonb) - Agent inputs
      - `output_data` (jsonb) - Agent outputs
      - `execution_time_ms` (integer) - Performance metric
      - `status` (text) - success, failed, pending
      - `error_message` (text, nullable) - Error details
      - `created_at` (timestamptz)

  ## Security
  - Enable RLS on all tables
  - Users can only access their own data
  - Agent logs are read-only for users
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  display_name text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create user_preferences table
CREATE TABLE IF NOT EXISTS user_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  favorite_genres jsonb DEFAULT '[]'::jsonb,
  favorite_tones jsonb DEFAULT '[]'::jsonb,
  preferred_duration text DEFAULT 'medium',
  visual_style text DEFAULT 'cinematic',
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Create stories table
CREATE TABLE IF NOT EXISTS stories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  prompt text NOT NULL,
  genre text NOT NULL,
  tone text NOT NULL,
  duration text DEFAULT 'medium',
  status text DEFAULT 'generating',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create story_structure table
CREATE TABLE IF NOT EXISTS story_structure (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  story_id uuid REFERENCES stories(id) ON DELETE CASCADE NOT NULL,
  exposition text,
  conflict text,
  climax text,
  resolution text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(story_id)
);

-- Create characters table
CREATE TABLE IF NOT EXISTS characters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  story_id uuid REFERENCES stories(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  personality text,
  goals text,
  dialogue_tone text,
  visual_description text,
  role text DEFAULT 'supporting',
  created_at timestamptz DEFAULT now()
);

-- Create scenes table
CREATE TABLE IF NOT EXISTS scenes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  story_id uuid REFERENCES stories(id) ON DELETE CASCADE NOT NULL,
  scene_number integer NOT NULL,
  title text NOT NULL,
  description text,
  location text,
  time_of_day text,
  mood text,
  dialogue text,
  visual_prompt text,
  image_url text,
  created_at timestamptz DEFAULT now()
);

-- Create music_cues table
CREATE TABLE IF NOT EXISTS music_cues (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  story_id uuid REFERENCES stories(id) ON DELETE CASCADE NOT NULL,
  scene_id uuid REFERENCES scenes(id) ON DELETE CASCADE,
  mood text,
  tempo text,
  instruments text,
  prompt text,
  audio_url text,
  created_at timestamptz DEFAULT now()
);

-- Create scripts table
CREATE TABLE IF NOT EXISTS scripts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  story_id uuid REFERENCES stories(id) ON DELETE CASCADE NOT NULL,
  content text NOT NULL,
  format text DEFAULT 'screenplay',
  version integer DEFAULT 1,
  created_at timestamptz DEFAULT now()
);

-- Create feedback table
CREATE TABLE IF NOT EXISTS feedback (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  story_id uuid REFERENCES stories(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  rating integer CHECK (rating >= 1 AND rating <= 5),
  scene_ratings jsonb DEFAULT '{}'::jsonb,
  liked_elements jsonb DEFAULT '[]'::jsonb,
  improvement_suggestions text,
  watch_time_seconds integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create agent_logs table
CREATE TABLE IF NOT EXISTS agent_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  story_id uuid REFERENCES stories(id) ON DELETE CASCADE NOT NULL,
  agent_name text NOT NULL,
  input_data jsonb,
  output_data jsonb,
  execution_time_ms integer,
  status text DEFAULT 'pending',
  error_message text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE stories ENABLE ROW LEVEL SECURITY;
ALTER TABLE story_structure ENABLE ROW LEVEL SECURITY;
ALTER TABLE characters ENABLE ROW LEVEL SECURITY;
ALTER TABLE scenes ENABLE ROW LEVEL SECURITY;
ALTER TABLE music_cues ENABLE ROW LEVEL SECURITY;
ALTER TABLE scripts ENABLE ROW LEVEL SECURITY;
ALTER TABLE feedback ENABLE ROW LEVEL SECURITY;
ALTER TABLE agent_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies for users
CREATE POLICY "Users can view own profile"
  ON users FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON users FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- RLS Policies for user_preferences
CREATE POLICY "Users can view own preferences"
  ON user_preferences FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own preferences"
  ON user_preferences FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own preferences"
  ON user_preferences FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for stories
CREATE POLICY "Users can view own stories"
  ON stories FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create stories"
  ON stories FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own stories"
  ON stories FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own stories"
  ON stories FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for story_structure
CREATE POLICY "Users can view own story structures"
  ON story_structure FOR SELECT
  TO authenticated
  USING (story_id IN (SELECT id FROM stories WHERE user_id = auth.uid()));

CREATE POLICY "Users can insert story structures"
  ON story_structure FOR INSERT
  TO authenticated
  WITH CHECK (story_id IN (SELECT id FROM stories WHERE user_id = auth.uid()));

CREATE POLICY "Users can update story structures"
  ON story_structure FOR UPDATE
  TO authenticated
  USING (story_id IN (SELECT id FROM stories WHERE user_id = auth.uid()))
  WITH CHECK (story_id IN (SELECT id FROM stories WHERE user_id = auth.uid()));

-- RLS Policies for characters
CREATE POLICY "Users can view own story characters"
  ON characters FOR SELECT
  TO authenticated
  USING (story_id IN (SELECT id FROM stories WHERE user_id = auth.uid()));

CREATE POLICY "Users can insert characters"
  ON characters FOR INSERT
  TO authenticated
  WITH CHECK (story_id IN (SELECT id FROM stories WHERE user_id = auth.uid()));

CREATE POLICY "Users can update characters"
  ON characters FOR UPDATE
  TO authenticated
  USING (story_id IN (SELECT id FROM stories WHERE user_id = auth.uid()))
  WITH CHECK (story_id IN (SELECT id FROM stories WHERE user_id = auth.uid()));

-- RLS Policies for scenes
CREATE POLICY "Users can view own story scenes"
  ON scenes FOR SELECT
  TO authenticated
  USING (story_id IN (SELECT id FROM stories WHERE user_id = auth.uid()));

CREATE POLICY "Users can insert scenes"
  ON scenes FOR INSERT
  TO authenticated
  WITH CHECK (story_id IN (SELECT id FROM stories WHERE user_id = auth.uid()));

CREATE POLICY "Users can update scenes"
  ON scenes FOR UPDATE
  TO authenticated
  USING (story_id IN (SELECT id FROM stories WHERE user_id = auth.uid()))
  WITH CHECK (story_id IN (SELECT id FROM stories WHERE user_id = auth.uid()));

-- RLS Policies for music_cues
CREATE POLICY "Users can view own story music"
  ON music_cues FOR SELECT
  TO authenticated
  USING (story_id IN (SELECT id FROM stories WHERE user_id = auth.uid()));

CREATE POLICY "Users can insert music cues"
  ON music_cues FOR INSERT
  TO authenticated
  WITH CHECK (story_id IN (SELECT id FROM stories WHERE user_id = auth.uid()));

-- RLS Policies for scripts
CREATE POLICY "Users can view own scripts"
  ON scripts FOR SELECT
  TO authenticated
  USING (story_id IN (SELECT id FROM stories WHERE user_id = auth.uid()));

CREATE POLICY "Users can insert scripts"
  ON scripts FOR INSERT
  TO authenticated
  WITH CHECK (story_id IN (SELECT id FROM stories WHERE user_id = auth.uid()));

-- RLS Policies for feedback
CREATE POLICY "Users can view own feedback"
  ON feedback FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert feedback"
  ON feedback FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own feedback"
  ON feedback FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for agent_logs
CREATE POLICY "Users can view own story logs"
  ON agent_logs FOR SELECT
  TO authenticated
  USING (story_id IN (SELECT id FROM stories WHERE user_id = auth.uid()));

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_stories_user_id ON stories(user_id);
CREATE INDEX IF NOT EXISTS idx_stories_created_at ON stories(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_characters_story_id ON characters(story_id);
CREATE INDEX IF NOT EXISTS idx_scenes_story_id ON scenes(story_id);
CREATE INDEX IF NOT EXISTS idx_scenes_scene_number ON scenes(story_id, scene_number);
CREATE INDEX IF NOT EXISTS idx_feedback_story_id ON feedback(story_id);
CREATE INDEX IF NOT EXISTS idx_agent_logs_story_id ON agent_logs(story_id);
