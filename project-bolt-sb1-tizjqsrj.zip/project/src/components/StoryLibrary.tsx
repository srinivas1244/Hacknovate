import { useEffect, useState } from 'react';
import { Film, Clock, Trash2 } from 'lucide-react';
import { supabase, Story } from '../lib/supabase';

type StoryLibraryProps = {
  userId: string;
  onSelectStory: (storyId: string) => void;
};

export function StoryLibrary({ userId, onSelectStory }: StoryLibraryProps) {
  const [stories, setStories] = useState<Story[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStories();
  }, [userId]);

  const loadStories = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('stories')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (data) {
      setStories(data);
    }
    setLoading(false);
  };

  const handleDelete = async (storyId: string, e: React.MouseEvent) => {
    e.stopPropagation();

    if (!confirm('Are you sure you want to delete this story?')) return;

    await supabase.from('stories').delete().eq('id', storyId);
    setStories(stories.filter(s => s.id !== storyId));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-4 border-slate-300 border-t-slate-700 rounded-full animate-spin" />
      </div>
    );
  }

  if (stories.length === 0) {
    return (
      <div className="text-center py-12">
        <Film className="w-16 h-16 text-slate-300 mx-auto mb-4" />
        <p className="text-slate-600">No stories yet. Generate your first story above!</p>
      </div>
    );
  }

  return (
    <div className="mt-12">
      <h2 className="text-2xl font-bold text-slate-900 mb-6">Your Story Library</h2>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {stories.map((story) => (
          <div
            key={story.id}
            onClick={() => onSelectStory(story.id)}
            className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow cursor-pointer overflow-hidden group"
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-3">
                <h3 className="font-bold text-lg text-slate-900 group-hover:text-slate-700 transition-colors">
                  {story.title}
                </h3>
                <button
                  onClick={(e) => handleDelete(story.id, e)}
                  className="text-slate-400 hover:text-red-600 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <p className="text-sm text-slate-600 line-clamp-2 mb-4">{story.prompt}</p>
              <div className="flex flex-wrap gap-2 mb-4">
                <span className="px-2 py-1 bg-slate-100 text-slate-700 text-xs rounded">
                  {story.genre}
                </span>
                <span className="px-2 py-1 bg-slate-100 text-slate-700 text-xs rounded">
                  {story.tone}
                </span>
                <span className="px-2 py-1 bg-slate-100 text-slate-700 text-xs rounded">
                  {story.duration}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs text-slate-500">
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {new Date(story.created_at).toLocaleDateString()}
                </div>
                <span
                  className={`px-2 py-1 rounded ${
                    story.status === 'completed'
                      ? 'bg-green-100 text-green-700'
                      : story.status === 'generating'
                      ? 'bg-blue-100 text-blue-700'
                      : 'bg-red-100 text-red-700'
                  }`}
                >
                  {story.status}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
