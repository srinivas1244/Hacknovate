import { useState } from 'react';
import { Film, Sparkles } from 'lucide-react';
import { StoryOrchestrator, GenerationProgress } from '../agents/orchestrator';

type StoryGeneratorProps = {
  userId: string;
  onStoryGenerated: (storyId: string) => void;
};

export function StoryGenerator({ userId, onStoryGenerated }: StoryGeneratorProps) {
  const [prompt, setPrompt] = useState('');
  const [genre, setGenre] = useState('sci-fi');
  const [tone, setTone] = useState('melancholic');
  const [duration, setDuration] = useState('medium');
  const [visualStyle, setVisualStyle] = useState('cinematic');
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState<GenerationProgress | null>(null);

  const orchestrator = new StoryOrchestrator();

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      alert('Please enter a story prompt');
      return;
    }

    if (!userId) {
      alert('User not initialized. Please refresh the page.');
      return;
    }

    console.log('Starting story generation with userId:', userId);
    setIsGenerating(true);
    setProgress({ stage: 'starting', progress: 0, message: 'Initializing agents...' });

    try {
      const storyId = await orchestrator.generateStory(
        userId,
        prompt,
        { genre, tone, duration, visualStyle },
        (prog) => setProgress(prog)
      );

      onStoryGenerated(storyId);
    } catch (error) {
      console.error('Generation failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      alert(`Failed to generate story: ${errorMessage}\n\nPlease check the console for details.`);
    } finally {
      setIsGenerating(false);
      setProgress(null);
    }
  };

  const examplePrompts = [
    'A lonely robot explores a forgotten city to find love.',
    'A detective cat in cyberpunk Tokyo solves impossible crimes.',
    'Two stars fall from the sky and become human for one night.',
    'An AI discovers emotions through old photographs in an abandoned house.'
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className="bg-gradient-to-r from-slate-900 to-slate-800 p-8 text-white">
          <div className="flex items-center gap-3 mb-4">
            <Film className="w-10 h-10" />
            <h1 className="text-3xl font-bold">StoryWeaver AI</h1>
          </div>
          <p className="text-slate-300 text-lg">
            Autonomous Story Director - Transform ideas into cinematic narratives
          </p>
        </div>

        <div className="p-8">
          <div className="mb-6">
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Story Prompt
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Enter your story idea..."
              className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent resize-none"
              rows={4}
              disabled={isGenerating}
            />
            <div className="mt-3 flex flex-wrap gap-2">
              {examplePrompts.map((example, idx) => (
                <button
                  key={idx}
                  onClick={() => setPrompt(example)}
                  className="text-xs px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-full transition-colors"
                  disabled={isGenerating}
                >
                  {example.slice(0, 40)}...
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-6">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Genre
              </label>
              <select
                value={genre}
                onChange={(e) => setGenre(e.target.value)}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent"
                disabled={isGenerating}
              >
                <option value="sci-fi">Sci-Fi</option>
                <option value="fantasy">Fantasy</option>
                <option value="romance">Romance</option>
                <option value="thriller">Thriller</option>
                <option value="mystery">Mystery</option>
                <option value="adventure">Adventure</option>
                <option value="drama">Drama</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Tone
              </label>
              <select
                value={tone}
                onChange={(e) => setTone(e.target.value)}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent"
                disabled={isGenerating}
              >
                <option value="melancholic">Melancholic</option>
                <option value="hopeful">Hopeful</option>
                <option value="dark">Dark</option>
                <option value="uplifting">Uplifting</option>
                <option value="mysterious">Mysterious</option>
                <option value="whimsical">Whimsical</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Duration
              </label>
              <select
                value={duration}
                onChange={(e) => setDuration(e.target.value)}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent"
                disabled={isGenerating}
              >
                <option value="short">Short (3 scenes)</option>
                <option value="medium">Medium (5 scenes)</option>
                <option value="long">Long (8 scenes)</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Visual Style
              </label>
              <select
                value={visualStyle}
                onChange={(e) => setVisualStyle(e.target.value)}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-slate-500 focus:border-transparent"
                disabled={isGenerating}
              >
                <option value="cinematic">Cinematic</option>
                <option value="anime">Anime</option>
                <option value="noir">Film Noir</option>
                <option value="watercolor">Watercolor</option>
                <option value="minimalist">Minimalist</option>
              </select>
            </div>
          </div>

          {progress && (
            <div className="mb-6 p-4 bg-slate-50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-slate-700">
                  {progress.message}
                </span>
                <span className="text-sm text-slate-600">{progress.progress}%</span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2">
                <div
                  className="bg-slate-700 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${progress.progress}%` }}
                />
              </div>
            </div>
          )}

          <button
            onClick={handleGenerate}
            disabled={isGenerating || !prompt.trim()}
            className="w-full bg-slate-900 hover:bg-slate-800 disabled:bg-slate-300 text-white font-semibold py-3 px-6 rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            {isGenerating ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Generating Story...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                Generate Story
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
