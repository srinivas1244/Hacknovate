import { useEffect, useState } from 'react';
import { ArrowLeft, Film, Users, Music, FileText, Star, Clock } from 'lucide-react';
import { supabase, Story, Character, Scene, Script, MusicCue } from '../lib/supabase';

type StoryViewerProps = {
  storyId: string;
  onBack: () => void;
};

export function StoryViewer({ storyId, onBack }: StoryViewerProps) {
  const [story, setStory] = useState<Story | null>(null);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [scenes, setScenes] = useState<Scene[]>([]);
  const [script, setScript] = useState<Script | null>(null);
  const [musicCues, setMusicCues] = useState<MusicCue[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'script' | 'scenes' | 'characters' | 'music'>('script');
  const [rating, setRating] = useState(0);

  useEffect(() => {
    loadStory();
  }, [storyId]);

  const loadStory = async () => {
    setLoading(true);

    const [storyRes, charactersRes, scenesRes, scriptRes, musicRes] = await Promise.all([
      supabase.from('stories').select('*').eq('id', storyId).single(),
      supabase.from('characters').select('*').eq('story_id', storyId).order('created_at'),
      supabase.from('scenes').select('*').eq('story_id', storyId).order('scene_number'),
      supabase.from('scripts').select('*').eq('story_id', storyId).order('version', { ascending: false }).limit(1).single(),
      supabase.from('music_cues').select('*').eq('story_id', storyId).order('created_at')
    ]);

    if (storyRes.data) setStory(storyRes.data);
    if (charactersRes.data) setCharacters(charactersRes.data);
    if (scenesRes.data) setScenes(scenesRes.data);
    if (scriptRes.data) setScript(scriptRes.data);
    if (musicRes.data) setMusicCues(musicRes.data);

    setLoading(false);
  };

  const handleRate = async (value: number) => {
    setRating(value);

    if (story) {
      await supabase.from('feedback').insert({
        story_id: story.id,
        user_id: story.user_id,
        rating: value,
        scene_ratings: {},
        liked_elements: []
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-8 h-8 border-4 border-slate-300 border-t-slate-700 rounded-full animate-spin" />
      </div>
    );
  }

  if (!story) {
    return (
      <div className="text-center py-12">
        <p className="text-slate-600">Story not found</p>
        <button onClick={onBack} className="mt-4 text-slate-700 hover:text-slate-900">
          Go Back
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      <button
        onClick={onBack}
        className="mb-6 flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors"
      >
        <ArrowLeft className="w-5 h-5" />
        Back to Generator
      </button>

      <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className="bg-gradient-to-r from-slate-900 to-slate-800 p-8 text-white">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">{story.title}</h1>
              <p className="text-slate-300 mb-4">{story.prompt}</p>
              <div className="flex gap-4 text-sm">
                <span className="px-3 py-1 bg-white/10 rounded-full">{story.genre}</span>
                <span className="px-3 py-1 bg-white/10 rounded-full">{story.tone}</span>
                <span className="px-3 py-1 bg-white/10 rounded-full">{story.duration}</span>
              </div>
            </div>
            <div className="flex flex-col items-end gap-2">
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((value) => (
                  <button
                    key={value}
                    onClick={() => handleRate(value)}
                    className="transition-colors"
                  >
                    <Star
                      className={`w-6 h-6 ${
                        value <= rating ? 'fill-yellow-400 text-yellow-400' : 'text-white/30'
                      }`}
                    />
                  </button>
                ))}
              </div>
              <span className="text-sm text-slate-300 flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {new Date(story.created_at).toLocaleDateString()}
              </span>
            </div>
          </div>
        </div>

        <div className="border-b border-slate-200">
          <div className="flex">
            <button
              onClick={() => setActiveTab('script')}
              className={`flex items-center gap-2 px-6 py-4 font-medium transition-colors border-b-2 ${
                activeTab === 'script'
                  ? 'border-slate-900 text-slate-900'
                  : 'border-transparent text-slate-500 hover:text-slate-700'
              }`}
            >
              <FileText className="w-5 h-5" />
              Script
            </button>
            <button
              onClick={() => setActiveTab('scenes')}
              className={`flex items-center gap-2 px-6 py-4 font-medium transition-colors border-b-2 ${
                activeTab === 'scenes'
                  ? 'border-slate-900 text-slate-900'
                  : 'border-transparent text-slate-500 hover:text-slate-700'
              }`}
            >
              <Film className="w-5 h-5" />
              Scenes ({scenes.length})
            </button>
            <button
              onClick={() => setActiveTab('characters')}
              className={`flex items-center gap-2 px-6 py-4 font-medium transition-colors border-b-2 ${
                activeTab === 'characters'
                  ? 'border-slate-900 text-slate-900'
                  : 'border-transparent text-slate-500 hover:text-slate-700'
              }`}
            >
              <Users className="w-5 h-5" />
              Characters ({characters.length})
            </button>
            <button
              onClick={() => setActiveTab('music')}
              className={`flex items-center gap-2 px-6 py-4 font-medium transition-colors border-b-2 ${
                activeTab === 'music'
                  ? 'border-slate-900 text-slate-900'
                  : 'border-transparent text-slate-500 hover:text-slate-700'
              }`}
            >
              <Music className="w-5 h-5" />
              Music ({musicCues.length})
            </button>
          </div>
        </div>

        <div className="p-8">
          {activeTab === 'script' && script && (
            <div className="prose max-w-none">
              <pre className="whitespace-pre-wrap font-mono text-sm bg-slate-50 p-6 rounded-lg overflow-x-auto">
                {script.content}
              </pre>
            </div>
          )}

          {activeTab === 'scenes' && (
            <div className="space-y-8">
              {scenes.map((scene) => (
                <div key={scene.id} className="border border-slate-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                  {scene.image_url && (
                    <div className="relative h-80 bg-slate-100 overflow-hidden">
                      <img
                        src={scene.image_url}
                        alt={scene.title}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                        }}
                      />
                      <div className="absolute top-4 left-4 bg-black/70 backdrop-blur-sm px-4 py-2 rounded-lg">
                        <span className="text-white font-semibold text-sm">Scene {scene.scene_number}</span>
                      </div>
                    </div>
                  )}
                  <div className="bg-gradient-to-r from-slate-50 to-slate-100 px-6 py-4 border-b border-slate-200">
                    <h3 className="font-bold text-xl text-slate-900 mb-2">{scene.title}</h3>
                    <div className="flex gap-4 text-sm text-slate-600">
                      <span className="flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                        {scene.location}
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                        {scene.time_of_day}
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-purple-500"></span>
                        {scene.mood}
                      </span>
                    </div>
                  </div>
                  <div className="p-6">
                    <p className="text-slate-700 leading-relaxed mb-4">{scene.description}</p>
                    {scene.dialogue && (
                      <div className="bg-gradient-to-br from-slate-50 to-slate-100 p-5 rounded-lg border border-slate-200 mb-4">
                        <p className="text-sm font-semibold text-slate-600 mb-3 flex items-center gap-2">
                          <span className="w-1 h-4 bg-slate-400 rounded"></span>
                          Dialogue
                        </p>
                        <p className="text-slate-700 whitespace-pre-wrap font-mono text-sm">{scene.dialogue}</p>
                      </div>
                    )}
                    <div className="bg-gradient-to-r from-blue-50 to-slate-50 p-4 rounded-lg border border-blue-100">
                      <p className="text-xs font-semibold text-slate-600 mb-2">Visual Prompt for Image Generation:</p>
                      <p className="text-sm text-slate-700 italic">{scene.visual_prompt}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'characters' && (
            <div className="grid gap-6 md:grid-cols-2">
              {characters.map((character) => (
                <div key={character.id} className="border border-slate-200 rounded-lg p-6">
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="text-xl font-bold text-slate-900">{character.name}</h3>
                    <span className="px-3 py-1 bg-slate-100 text-slate-700 text-xs font-medium rounded-full">
                      {character.role}
                    </span>
                  </div>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm font-semibold text-slate-600">Personality</p>
                      <p className="text-slate-700">{character.personality}</p>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-600">Goals</p>
                      <p className="text-slate-700">{character.goals}</p>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-600">Visual Description</p>
                      <p className="text-slate-700">{character.visual_description}</p>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-600">Dialogue Tone</p>
                      <p className="text-slate-700">{character.dialogue_tone}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'music' && (
            <div className="space-y-4">
              {musicCues.map((cue, index) => (
                <div key={cue.id} className="border border-slate-200 rounded-lg p-6">
                  <div className="flex items-center gap-3 mb-3">
                    <Music className="w-5 h-5 text-slate-500" />
                    <h3 className="font-bold text-slate-900">Cue {index + 1}</h3>
                  </div>
                  <div className="grid grid-cols-3 gap-4 mb-4 text-sm">
                    <div>
                      <span className="text-slate-600 font-semibold">Mood:</span>
                      <span className="ml-2 text-slate-700">{cue.mood}</span>
                    </div>
                    <div>
                      <span className="text-slate-600 font-semibold">Tempo:</span>
                      <span className="ml-2 text-slate-700">{cue.tempo}</span>
                    </div>
                    <div>
                      <span className="text-slate-600 font-semibold">Instruments:</span>
                      <span className="ml-2 text-slate-700">{cue.instruments}</span>
                    </div>
                  </div>
                  <div className="bg-slate-50 p-4 rounded text-sm text-slate-700">
                    <span className="font-semibold">Prompt:</span> {cue.prompt}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
