import { SceneData } from './sceneAgent';

export type MusicCueData = {
  scene_id: string | null;
  mood: string;
  tempo: string;
  instruments: string;
  prompt: string;
};

export class MusicAgent {
  async createMusicCues(scenes: SceneData[], tone: string): Promise<MusicCueData[]> {
    const cues: MusicCueData[] = [];

    for (const scene of scenes) {
      cues.push(this.createCueForScene(scene, tone));
    }

    return cues;
  }

  private createCueForScene(scene: SceneData, tone: string): MusicCueData {
    const moodMap: Record<string, {
      tempo: string;
      instruments: string;
      description: string;
    }> = {
      contemplative: {
        tempo: 'slow',
        instruments: 'ambient pads, soft piano, ethereal textures',
        description: 'reflective and introspective'
      },
      tense: {
        tempo: 'medium',
        instruments: 'pulsing synths, subtle percussion, rising strings',
        description: 'building tension'
      },
      intense: {
        tempo: 'fast',
        instruments: 'dramatic orchestra, powerful drums, electronic elements',
        description: 'climactic and powerful'
      },
      hopeful: {
        tempo: 'medium',
        instruments: 'warm strings, gentle piano, uplifting harmonies',
        description: 'optimistic and peaceful'
      }
    };

    const musicData = moodMap[scene.mood] || moodMap.contemplative;

    return {
      scene_id: null,
      mood: scene.mood,
      tempo: musicData.tempo,
      instruments: musicData.instruments,
      prompt: `${tone} music, ${musicData.description}, ${musicData.tempo} tempo, featuring ${musicData.instruments}, cinematic quality`
    };
  }

  generateOverallTheme(tone: string, themes: string[]): string {
    return `Main theme music for ${tone} story about ${themes.join(', ')}, memorable melody, emotional depth, cinematic orchestration`;
  }
}
