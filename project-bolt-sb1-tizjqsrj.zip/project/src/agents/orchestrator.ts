import { supabase } from '../lib/supabase';
import { StoryDirectorAgent } from './storyDirector';
import { CharacterAgent } from './characterAgent';
import { SceneAgent } from './sceneAgent';
import { MusicAgent } from './musicAgent';
import { ScriptAgent } from './scriptAgent';

export type GenerationProgress = {
  stage: string;
  progress: number;
  message: string;
};

export class StoryOrchestrator {
  private storyDirector = new StoryDirectorAgent();
  private characterAgent = new CharacterAgent();
  private sceneAgent = new SceneAgent();
  private musicAgent = new MusicAgent();
  private scriptAgent = new ScriptAgent();

  async generateStory(
    userId: string,
    prompt: string,
    preferences: {
      genre: string;
      tone: string;
      duration: string;
      visualStyle?: string;
    },
    onProgress?: (progress: GenerationProgress) => void
  ): Promise<string> {
    const startTime = Date.now();

    try {
      onProgress?.({
        stage: 'director',
        progress: 0,
        message: 'Story Director analyzing your prompt...'
      });

      const outline = await this.storyDirector.createOutline(prompt, preferences);

      const { data: story, error: storyError } = await supabase
        .from('stories')
        .insert({
          user_id: userId,
          title: outline.title,
          prompt,
          genre: preferences.genre,
          tone: preferences.tone,
          duration: preferences.duration,
          status: 'generating'
        })
        .select()
        .single();

      if (storyError || !story) {
        console.error('Story creation error:', storyError);
        throw new Error(`Failed to create story record: ${storyError?.message || 'Unknown error'}`);
      }

      await this.logAgent(story.id, 'story_director', { prompt, preferences }, outline, Date.now() - startTime);

      await supabase.from('story_structure').insert({
        story_id: story.id,
        exposition: outline.structure.exposition,
        conflict: outline.structure.conflict,
        climax: outline.structure.climax,
        resolution: outline.structure.resolution
      });

      onProgress?.({
        stage: 'characters',
        progress: 20,
        message: 'Character Agent creating personalities...'
      });

      const characterStartTime = Date.now();
      const characters = await this.characterAgent.createCharacters(
        prompt,
        outline,
        outline.suggestedCharacterCount
      );

      await this.logAgent(
        story.id,
        'character_agent',
        { outline },
        characters,
        Date.now() - characterStartTime
      );

      const characterInserts = characters.map(char => ({
        story_id: story.id,
        name: char.name,
        personality: char.personality,
        goals: char.goals,
        dialogue_tone: char.dialogue_tone,
        visual_description: char.visual_description,
        role: char.role
      }));

      await supabase.from('characters').insert(characterInserts);

      onProgress?.({
        stage: 'scenes',
        progress: 40,
        message: 'Scene Agent building visual storyboard...'
      });

      const sceneStartTime = Date.now();
      const scenes = await this.sceneAgent.createScenes(
        outline,
        characters,
        outline.suggestedSceneCount,
        preferences.tone,
        preferences.visualStyle || 'cinematic'
      );

      await this.logAgent(story.id, 'scene_agent', { outline, characters }, scenes, Date.now() - sceneStartTime);

      const sceneInserts = scenes.map(scene => ({
        story_id: story.id,
        ...scene
      }));

      const { data: insertedScenes } = await supabase
        .from('scenes')
        .insert(sceneInserts)
        .select();

      onProgress?.({
        stage: 'music',
        progress: 60,
        message: 'Music Agent composing soundscape...'
      });

      const musicStartTime = Date.now();
      const musicCues = await this.musicAgent.createMusicCues(scenes, preferences.tone);

      await this.logAgent(story.id, 'music_agent', { scenes }, musicCues, Date.now() - musicStartTime);

      const musicInserts = musicCues.map((cue, index) => ({
        story_id: story.id,
        scene_id: insertedScenes?.[index]?.id || null,
        mood: cue.mood,
        tempo: cue.tempo,
        instruments: cue.instruments,
        prompt: cue.prompt
      }));

      await supabase.from('music_cues').insert(musicInserts);

      onProgress?.({
        stage: 'script',
        progress: 80,
        message: 'Script Agent assembling final screenplay...'
      });

      const scriptStartTime = Date.now();
      const script = await this.scriptAgent.createScript(
        outline,
        characters,
        scenes,
        musicCues,
        'screenplay'
      );

      await this.logAgent(
        story.id,
        'script_agent',
        { outline, characters, scenes, musicCues },
        { script },
        Date.now() - scriptStartTime
      );

      await supabase.from('scripts').insert({
        story_id: story.id,
        content: script,
        format: 'screenplay',
        version: 1
      });

      await supabase
        .from('stories')
        .update({ status: 'completed', updated_at: new Date().toISOString() })
        .eq('id', story.id);

      onProgress?.({
        stage: 'complete',
        progress: 100,
        message: 'Story generation complete!'
      });

      return story.id;
    } catch (error) {
      console.error('Story generation error:', error);
      throw error;
    }
  }

  private async logAgent(
    storyId: string,
    agentName: string,
    input: any,
    output: any,
    executionTime: number
  ): Promise<void> {
    await supabase.from('agent_logs').insert({
      story_id: storyId,
      agent_name: agentName,
      input_data: input,
      output_data: output,
      execution_time_ms: executionTime,
      status: 'success'
    });
  }
}
