import { StoryOutline } from './storyDirector';
import { CharacterProfile } from './characterAgent';

export type SceneData = {
  scene_number: number;
  title: string;
  description: string;
  location: string;
  time_of_day: string;
  mood: string;
  dialogue: string;
  visual_prompt: string;
  image_url?: string;
};

export class SceneAgent {
  async createScenes(
    outline: StoryOutline,
    characters: CharacterProfile[],
    sceneCount: number,
    tone: string,
    visualStyle: string
  ): Promise<SceneData[]> {
    const scenes: SceneData[] = [];
    const protagonist = characters.find(c => c.role === 'protagonist')?.name || 'Hero';


    for (let i = 0; i < sceneCount; i++) {
      const progress = i / (sceneCount - 1);
      const phase = this.getPhase(progress);

      const scene = this.createScene(
        i + 1,
        phase,
        outline,
        characters,
        protagonist,
        tone,
        visualStyle
      );

      scene.image_url = this.generateImageUrl(scene.mood, scene.location, visualStyle);
      scenes.push(scene);
    }

    return scenes;
  }

  private getPhase(progress: number): string {
    if (progress < 0.25) return 'exposition';
    if (progress < 0.6) return 'rising';
    if (progress < 0.85) return 'climax';
    return 'resolution';
  }

  private createScene(
    number: number,
    phase: string,
    outline: StoryOutline,
    characters: CharacterProfile[],
    protagonist: string,
    tone: string,
    visualStyle: string
  ): SceneData {
    const sceneTemplates = {
      exposition: {
        title: 'The Beginning',
        description: outline.structure.exposition,
        mood: 'contemplative',
        time: 'dawn'
      },
      rising: {
        title: 'The Challenge',
        description: outline.structure.conflict,
        mood: 'tense',
        time: 'day'
      },
      climax: {
        title: 'The Confrontation',
        description: outline.structure.climax,
        mood: 'intense',
        time: 'dusk'
      },
      resolution: {
        title: 'The Transformation',
        description: outline.structure.resolution,
        mood: 'hopeful',
        time: 'night'
      }
    };

    const template = sceneTemplates[phase as keyof typeof sceneTemplates] || sceneTemplates.exposition;

    const location = this.generateLocation(phase, tone);
    const dialogue = this.generateDialogue(phase, characters, protagonist);

    return {
      scene_number: number,
      title: `Scene ${number}: ${template.title}`,
      description: template.description,
      location,
      time_of_day: template.time,
      mood: template.mood,
      dialogue,
      visual_prompt: this.generateVisualPrompt(
        location,
        template.time,
        template.mood,
        visualStyle,
        characters[0]?.visual_description || 'a lone figure'
      )
    };
  }

  private generateLocation(phase: string, _tone: string): string {
    const locations: Record<string, string[]> = {
      exposition: ['abandoned street', 'quiet rooftop', 'empty plaza', 'forgotten garden'],
      rising: ['narrow alley', 'crowded market', 'industrial zone', 'hidden passage'],
      climax: ['towering structure', 'open battlefield', 'edge of precipice', 'central chamber'],
      resolution: ['peaceful overlook', 'restored place', 'new horizon', 'sacred space']
    };

    const options = locations[phase] || locations.exposition;
    return options[Math.floor(Math.random() * options.length)];
  }

  private generateDialogue(phase: string, characters: CharacterProfile[], protagonist: string): string {
    const dialogues: Record<string, string> = {
      exposition: `${protagonist}: "There has to be more to this... something I'm meant to find."`,
      rising: `${protagonist}: "I've come too far to turn back now."\n${characters[1]?.name || 'Voice'}: "Then you'll face what comes next."`,
      climax: `${protagonist}: "This is it. Everything leads to this moment."\n[The tension reaches its breaking point]`,
      resolution: `${protagonist}: "I understand now. This is where the journey truly begins."`
    };

    return dialogues[phase] || dialogues.exposition;
  }

  private generateVisualPrompt(
    location: string,
    time: string,
    mood: string,
    style: string,
    characterDesc: string
  ): string {
    return `${style} shot of ${characterDesc} in ${location} at ${time}, ${mood} atmosphere, cinematic lighting, dramatic composition, high detail`;
  }

  private generateImageUrl(mood: string, location: string, _visualStyle: string): string {
    const imageMap: Record<string, string[]> = {
      'abandoned street': [
        'https://images.pexels.com/photos/3214116/pexels-photo-3214116.jpeg?auto=compress&cs=tinysrgb&w=1200',
        'https://images.pexels.com/photos/2228561/pexels-photo-2228561.jpeg?auto=compress&cs=tinysrgb&w=1200',
      ],
      'quiet rooftop': [
        'https://images.pexels.com/photos/681335/pexels-photo-681335.jpeg?auto=compress&cs=tinysrgb&w=1200',
        'https://images.pexels.com/photos/1647962/pexels-photo-1647962.jpeg?auto=compress&cs=tinysrgb&w=1200',
      ],
      'narrow alley': [
        'https://images.pexels.com/photos/2246476/pexels-photo-2246476.jpeg?auto=compress&cs=tinysrgb&w=1200',
        'https://images.pexels.com/photos/1108701/pexels-photo-1108701.jpeg?auto=compress&cs=tinysrgb&w=1200',
      ],
      'crowded market': [
        'https://images.pexels.com/photos/1166209/pexels-photo-1166209.jpeg?auto=compress&cs=tinysrgb&w=1200',
        'https://images.pexels.com/photos/2563681/pexels-photo-2563681.jpeg?auto=compress&cs=tinysrgb&w=1200',
      ],
      'towering structure': [
        'https://images.pexels.com/photos/325185/pexels-photo-325185.jpeg?auto=compress&cs=tinysrgb&w=1200',
        'https://images.pexels.com/photos/2102587/pexels-photo-2102587.jpeg?auto=compress&cs=tinysrgb&w=1200',
      ],
      'peaceful overlook': [
        'https://images.pexels.com/photos/417074/pexels-photo-417074.jpeg?auto=compress&cs=tinysrgb&w=1200',
        'https://images.pexels.com/photos/346529/pexels-photo-346529.jpeg?auto=compress&cs=tinysrgb&w=1200',
      ],
      'default': [
        'https://images.pexels.com/photos/1287075/pexels-photo-1287075.jpeg?auto=compress&cs=tinysrgb&w=1200',
        'https://images.pexels.com/photos/2014422/pexels-photo-2014422.jpeg?auto=compress&cs=tinysrgb&w=1200',
      ]
    };

    const images = imageMap[location] || imageMap['default'];
    const moodSeed = mood.length;
    return images[moodSeed % images.length];
  }
}
