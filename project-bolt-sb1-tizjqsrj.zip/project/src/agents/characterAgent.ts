import { StoryOutline } from './storyDirector';

export type CharacterProfile = {
  name: string;
  personality: string;
  goals: string;
  dialogue_tone: string;
  visual_description: string;
  role: 'protagonist' | 'antagonist' | 'supporting';
};

export class CharacterAgent {
  async createCharacters(
    prompt: string,
    outline: StoryOutline,
    count: number
  ): Promise<CharacterProfile[]> {
    const characters: CharacterProfile[] = [];

    characters.push(this.createProtagonist(prompt, outline));

    if (count > 1) {
      characters.push(this.createSupporting(prompt, outline, 'ally'));
    }

    if (count > 2) {
      characters.push(this.createAntagonist(prompt, outline));
    }

    if (count > 3) {
      characters.push(this.createSupporting(prompt, outline, 'mentor'));
    }

    return characters;
  }

  private createProtagonist(prompt: string, outline: StoryOutline): CharacterProfile {
    const nameMatch = prompt.match(/(?:a|an|the)\s+(\w+)/i);
    const type = nameMatch ? nameMatch[1] : 'wanderer';

    const names = this.getNames(type, 'protagonist');

    return {
      name: names[0],
      personality: 'Determined, curious, and resourceful. Driven by a deep need to find meaning.',
      goals: outline.structure.exposition.split('-')[0].trim(),
      dialogue_tone: 'Reflective and earnest, speaks with purpose',
      visual_description: `A ${type} with weathered features, carrying the weight of their journey`,
      role: 'protagonist'
    };
  }

  private createAntagonist(_prompt: string, _outline: StoryOutline): CharacterProfile {
    return {
      name: 'Shadow',
      personality: 'Complex and driven by their own logic. Not evil, but opposing.',
      goals: 'To maintain the status quo or achieve conflicting objectives',
      dialogue_tone: 'Calculated and firm, speaks with authority',
      visual_description: 'Imposing presence, sharp features, commanding attention',
      role: 'antagonist'
    };
  }

  private createSupporting(
    _prompt: string,
    _outline: StoryOutline,
    type: 'ally' | 'mentor'
  ): CharacterProfile {
    if (type === 'ally') {
      return {
        name: 'Echo',
        personality: 'Loyal and optimistic, provides emotional support',
        goals: 'To help the protagonist succeed and find their own purpose',
        dialogue_tone: 'Warm and encouraging, speaks from the heart',
        visual_description: 'Kind eyes, approachable demeanor, dressed practically',
        role: 'supporting'
      };
    } else {
      return {
        name: 'Sage',
        personality: 'Wise and experienced, with hidden depths',
        goals: 'To guide without controlling, to teach through experience',
        dialogue_tone: 'Measured and thoughtful, speaks in meaningful phrases',
        visual_description: 'Weathered by time, carries wisdom in their posture',
        role: 'supporting'
      };
    }
  }

  private getNames(type: string, _role: string): string[] {
    const namesByType: Record<string, string[]> = {
      robot: ['Unit-7', 'Cipher', 'Nova', 'Spark'],
      detective: ['Morgan', 'Vale', 'Dash', 'Quinn'],
      warrior: ['Kael', 'Raven', 'Storm', 'Blade'],
      default: ['Alex', 'River', 'Sky', 'Phoenix']
    };

    return namesByType[type.toLowerCase()] || namesByType.default;
  }
}
