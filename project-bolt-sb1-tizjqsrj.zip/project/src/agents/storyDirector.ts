export type StoryPreferences = {
  genre: string;
  tone: string;
  duration: string;
  visualStyle?: string;
};

export type StoryOutline = {
  title: string;
  structure: {
    exposition: string;
    conflict: string;
    climax: string;
    resolution: string;
  };
  themes: string[];
  suggestedCharacterCount: number;
  suggestedSceneCount: number;
};

export class StoryDirectorAgent {
  async createOutline(prompt: string, preferences: StoryPreferences): Promise<StoryOutline> {
    const durationScenes = {
      short: 3,
      medium: 5,
      long: 8
    };

    const sceneCount = durationScenes[preferences.duration as keyof typeof durationScenes] || 5;

    const outline: StoryOutline = {
      title: this.generateTitle(prompt),
      structure: {
        exposition: `Opening: ${this.extractEssence(prompt)} - Establish the world and main character.`,
        conflict: `The main character faces a challenge that drives the story forward, testing their resolve.`,
        climax: `The confrontation reaches its peak, with everything at stake.`,
        resolution: `The story concludes with transformation and meaning.`
      },
      themes: this.extractThemes(prompt, preferences),
      suggestedCharacterCount: Math.min(sceneCount, 4),
      suggestedSceneCount: sceneCount
    };

    return outline;
  }

  private generateTitle(prompt: string): string {
    const words = prompt.split(' ').slice(0, 5);
    const meaningful = words.filter(w => w.length > 3);
    return meaningful.slice(0, 3).map(w =>
      w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()
    ).join(' ');
  }

  private extractEssence(prompt: string): string {
    return prompt.split('.')[0].trim();
  }

  private extractThemes(prompt: string, preferences: StoryPreferences): string[] {
    const themeMap: Record<string, string[]> = {
      'sci-fi': ['technology', 'humanity', 'future'],
      'fantasy': ['magic', 'destiny', 'courage'],
      'romance': ['love', 'connection', 'vulnerability'],
      'thriller': ['danger', 'survival', 'trust'],
      'mystery': ['truth', 'deception', 'revelation'],
      'adventure': ['discovery', 'bravery', 'freedom'],
      'drama': ['conflict', 'emotion', 'growth']
    };

    const baseThemes = themeMap[preferences.genre.toLowerCase()] || ['journey', 'change', 'hope'];

    if (prompt.toLowerCase().includes('love')) baseThemes.push('love');
    if (prompt.toLowerCase().includes('lost') || prompt.toLowerCase().includes('find')) {
      baseThemes.push('discovery');
    }

    return baseThemes.slice(0, 3);
  }
}
