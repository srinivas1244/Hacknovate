import { StoryOutline } from './storyDirector';
import { CharacterProfile } from './characterAgent';
import { SceneData } from './sceneAgent';
import { MusicCueData } from './musicAgent';

export type ScriptFormat = 'screenplay' | 'narrative' | 'storyboard';

export class ScriptAgent {
  async createScript(
    outline: StoryOutline,
    characters: CharacterProfile[],
    scenes: SceneData[],
    musicCues: MusicCueData[],
    format: ScriptFormat = 'screenplay'
  ): Promise<string> {
    if (format === 'screenplay') {
      return this.generateScreenplay(outline, characters, scenes, musicCues);
    } else if (format === 'narrative') {
      return this.generateNarrative(outline, characters, scenes);
    } else {
      return this.generateStoryboard(outline, scenes, musicCues);
    }
  }

  private generateScreenplay(
    outline: StoryOutline,
    characters: CharacterProfile[],
    scenes: SceneData[],
    musicCues: MusicCueData[]
  ): string {
    let script = `${outline.title.toUpperCase()}\n`;
    script += `A ${outline.themes.join(', ')} story\n\n`;
    script += `="=".repeat(60)}\n\n`;

    script += `CHARACTERS:\n\n`;
    characters.forEach(char => {
      script += `${char.name.toUpperCase()} - ${char.role}\n`;
      script += `  ${char.personality}\n`;
      script += `  ${char.visual_description}\n\n`;
    });

    script += `\n${"=".repeat(60)}\n\n`;

    scenes.forEach((scene, index) => {
      const musicCue = musicCues[index];

      script += `${scene.title.toUpperCase()}\n\n`;
      script += `INT./EXT. ${scene.location.toUpperCase()} - ${scene.time_of_day.toUpperCase()}\n\n`;
      script += `[MOOD: ${scene.mood.toUpperCase()}]\n`;

      if (musicCue) {
        script += `[MUSIC: ${musicCue.prompt}]\n`;
      }

      script += `\n${scene.description}\n\n`;

      if (scene.dialogue) {
        const dialogueLines = scene.dialogue.split('\n');
        dialogueLines.forEach(line => {
          if (line.includes(':')) {
            const [speaker, speech] = line.split(':');
            script += `\n${speaker.trim().toUpperCase()}\n`;
            script += `${speech.trim()}\n`;
          } else {
            script += `\n${line}\n`;
          }
        });
      }

      script += `\n${"=".repeat(60)}\n\n`;
    });

    script += `\nTHE END\n`;

    return script;
  }

  private generateNarrative(
    outline: StoryOutline,
    characters: CharacterProfile[],
    scenes: SceneData[]
  ): string {
    let narrative = `# ${outline.title}\n\n`;
    narrative += `## A Tale of ${outline.themes.join(', ')}\n\n`;

    const protagonist = characters.find(c => c.role === 'protagonist');
    if (protagonist) {
      narrative += `Our story follows ${protagonist.name}, ${protagonist.personality.toLowerCase()}. `;
      narrative += `${protagonist.goals}.\n\n`;
    }

    scenes.forEach(scene => {
      narrative += `### ${scene.title}\n\n`;
      narrative += `*${scene.location}, ${scene.time_of_day}*\n\n`;
      narrative += `${scene.description}\n\n`;

      if (scene.dialogue) {
        narrative += `${scene.dialogue}\n\n`;
      }

      narrative += `---\n\n`;
    });

    narrative += `\n*Fin*\n`;

    return narrative;
  }

  private generateStoryboard(
    outline: StoryOutline,
    scenes: SceneData[],
    musicCues: MusicCueData[]
  ): string {
    let storyboard = `${outline.title} - STORYBOARD\n`;
    storyboard += `${"=".repeat(60)}\n\n`;

    scenes.forEach((scene, index) => {
      const musicCue = musicCues[index];

      storyboard += `[SCENE ${scene.scene_number}]\n`;
      storyboard += `Title: ${scene.title}\n`;
      storyboard += `Location: ${scene.location}\n`;
      storyboard += `Time: ${scene.time_of_day}\n`;
      storyboard += `Mood: ${scene.mood}\n\n`;

      storyboard += `VISUAL:\n${scene.visual_prompt}\n\n`;

      storyboard += `ACTION:\n${scene.description}\n\n`;

      if (scene.dialogue) {
        storyboard += `DIALOGUE:\n${scene.dialogue}\n\n`;
      }

      if (musicCue) {
        storyboard += `AUDIO:\n${musicCue.prompt}\n`;
      }

      storyboard += `\n${"-".repeat(60)}\n\n`;
    });

    return storyboard;
  }
}
