import { useState, useEffect } from 'react';
import { supabase } from './lib/supabase';
import { StoryGenerator } from './components/StoryGenerator';
import { StoryViewer } from './components/StoryViewer';
import { StoryLibrary } from './components/StoryLibrary';

function App() {
  const [userId, setUserId] = useState<string>('');
  const [selectedStory, setSelectedStory] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    initUser();
  }, []);

  const initUser = async () => {
    try {
      const storedUserId = localStorage.getItem('storyweaver_user_id');

      if (storedUserId) {
        console.log('Found existing user ID in localStorage:', storedUserId);

        const { data: existingUser, error: checkError } = await supabase
          .from('users')
          .select('id')
          .eq('id', storedUserId)
          .maybeSingle();

        if (checkError) {
          console.error('Error checking user:', checkError);
          throw checkError;
        }

        if (existingUser) {
          console.log('User exists in database');
          setUserId(storedUserId);
          setLoading(false);
          return;
        } else {
          console.log('User not found in database, creating new user');
          localStorage.removeItem('storyweaver_user_id');
        }
      }

      const newUserId = crypto.randomUUID();
      console.log('Creating new user:', newUserId);

      const { error: userError } = await supabase.from('users').insert({
        id: newUserId,
        email: `user_${newUserId.slice(0, 8)}@storyweaver.local`,
        display_name: 'Story Creator'
      });

      if (userError) {
        console.error('Failed to create user:', userError);
        throw userError;
      }

      const { error: prefError } = await supabase.from('user_preferences').insert({
        user_id: newUserId,
        favorite_genres: ['sci-fi', 'fantasy'],
        favorite_tones: ['melancholic', 'hopeful'],
        preferred_duration: 'medium',
        visual_style: 'cinematic'
      });

      if (prefError) {
        console.error('Failed to create preferences:', prefError);
        throw prefError;
      }

      localStorage.setItem('storyweaver_user_id', newUserId);
      setUserId(newUserId);
      console.log('User initialized successfully');
    } catch (error) {
      console.error('User initialization failed:', error);
      alert('Failed to initialize user. Please refresh the page.');
    } finally {
      setLoading(false);
    }
  };

  const handleStoryGenerated = (storyId: string) => {
    setSelectedStory(storyId);
  };

  const handleBack = () => {
    setSelectedStory(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-slate-100 to-slate-200 flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-slate-300 border-t-slate-700 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-slate-100 to-slate-200">
      <div className="container mx-auto px-4 py-12">
        {selectedStory ? (
          <StoryViewer storyId={selectedStory} onBack={handleBack} />
        ) : (
          <>
            <StoryGenerator userId={userId} onStoryGenerated={handleStoryGenerated} />
            <StoryLibrary userId={userId} onSelectStory={setSelectedStory} />
          </>
        )}
      </div>

      <footer className="mt-16 pb-8 text-center text-sm text-slate-500">
        <p>StoryWeaver AI - Autonomous Multi-Agent Story Generation System</p>
        <p className="mt-1">Powered by Story Director, Character, Scene, Music & Script Agents</p>
      </footer>
    </div>
  );
}

export default App;
