import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Story = {
  id: string;
  user_id: string;
  title: string;
  prompt: string;
  genre: string;
  tone: string;
  duration: string;
  status: 'generating' | 'completed' | 'failed';
  created_at: string;
  updated_at: string;
};

export type Character = {
  id: string;
  story_id: string;
  name: string;
  personality: string;
  goals: string;
  dialogue_tone: string;
  visual_description: string;
  role: string;
  created_at: string;
};

export type Scene = {
  id: string;
  story_id: string;
  scene_number: number;
  title: string;
  description: string;
  location: string;
  time_of_day: string;
  mood: string;
  dialogue: string;
  visual_prompt: string;
  image_url: string | null;
  created_at: string;
};

export type StoryStructure = {
  id: string;
  story_id: string;
  exposition: string;
  conflict: string;
  climax: string;
  resolution: string;
  created_at: string;
};

export type MusicCue = {
  id: string;
  story_id: string;
  scene_id: string | null;
  mood: string;
  tempo: string;
  instruments: string;
  prompt: string;
  audio_url: string | null;
  created_at: string;
};

export type Script = {
  id: string;
  story_id: string;
  content: string;
  format: string;
  version: number;
  created_at: string;
};
