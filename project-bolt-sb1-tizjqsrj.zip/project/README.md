# StoryWeaver AI - Autonomous Story Director MVP

An intelligent, multi-agent system that autonomously writes, visualizes, scores, and adapts full stories based on user prompts and feedback.

## Features

### Multi-Agent Architecture

The system uses 6 specialized agents that collaborate like a film studio team:

1. **Story Director Agent** - Main controller that breaks user goals into subtasks and defines story structure (exposition, conflict, climax, resolution)

2. **Character Agent** - Designs characters with personalities, goals, dialogue tones, and visual descriptions

3. **Scene Agent** - Builds visual settings and cinematic scene descriptions with locations, moods, and storyboard scripts

4. **Music Agent** - Composes adaptive music prompts matching story tone, with tempo and instrumentation details

5. **Script Agent** - Merges all agent outputs into cohesive screenplays, narratives, or storyboards

6. **Feedback System** - Collects user ratings and reactions to enable adaptive learning

### Core Capabilities

- End-to-end story generation from one-line prompts
- Character personality and visual design
- Scene-by-scene storyboard creation
- Music composition prompts for each scene
- Multiple output formats (screenplay, narrative, storyboard)
- Persistent memory with Supabase database
- Story library with version history
- User preference tracking

## Tech Stack

- **Frontend**: React + TypeScript + Vite + Tailwind CSS
- **Database**: Supabase (PostgreSQL)
- **Agents**: Custom TypeScript agent system
- **Icons**: Lucide React
- **Styling**: Tailwind CSS with custom design system

## Database Schema

The system uses a comprehensive database schema with 10 tables:

- `users` - User accounts
- `user_preferences` - Genre, tone, and style preferences
- `stories` - Main story records
- `story_structure` - 4-act structure details
- `characters` - Character profiles and descriptions
- `scenes` - Scene-by-scene breakdowns
- `music_cues` - Music composition prompts
- `scripts` - Final screenplay outputs
- `feedback` - User ratings and reactions
- `agent_logs` - Performance monitoring and debugging

## How It Works

### Story Generation Flow

1. User enters a prompt (e.g., "A lonely robot explores a forgotten city to find love")
2. Select preferences: genre, tone, duration, visual style
3. Story Director Agent analyzes prompt and creates outline
4. Character Agent generates protagonist, antagonist, and supporting characters
5. Scene Agent builds cinematic scenes with visual prompts
6. Music Agent composes mood-appropriate soundscape prompts
7. Script Agent assembles everything into final screenplay
8. User can view, rate, and provide feedback

### Adaptive Learning

- User ratings are stored per story
- Feedback influences future generations
- Genre and tone preferences are tracked
- Agent execution times are logged for optimization

## Usage

### Generate a Story

1. Enter your story prompt
2. Configure preferences (genre, tone, duration, visual style)
3. Click "Generate Story"
4. Watch real-time progress as agents work
5. View completed story with multiple tabs

### View Stories

- **Script Tab**: Full screenplay format with dialogue and stage directions
- **Scenes Tab**: Individual scene breakdowns with visual prompts
- **Characters Tab**: Character profiles and descriptions
- **Music Tab**: Music composition prompts for each scene

### Rate Stories

- 5-star rating system
- Feedback stored for learning
- Helps improve future generations

## Example Prompts

- "A lonely robot explores a forgotten city to find love."
- "A detective cat in cyberpunk Tokyo solves impossible crimes."
- "Two stars fall from the sky and become human for one night."
- "An AI discovers emotions through old photographs in an abandoned house."

## Agent Architecture

### Story Director
- Breaks prompts into structured outlines
- Defines 4-act structure
- Determines character and scene counts
- Extracts themes and tone

### Character Agent
- Creates protagonist, antagonist, supporting roles
- Generates personality profiles
- Defines goals and motivations
- Describes visual appearance
- Sets dialogue tone

### Scene Agent
- Maps story structure to scenes
- Generates locations and settings
- Creates visual prompts for image generation
- Writes scene descriptions and dialogue
- Sets mood and time of day

### Music Agent
- Analyzes scene moods
- Determines tempo and instruments
- Creates music generation prompts
- Matches tone to story

### Script Agent
- Formats output (screenplay/narrative/storyboard)
- Merges all agent data
- Creates cohesive final product
- Includes visual and audio cues

## Future Enhancements

- AI image generation integration (DALL-E, Stable Diffusion)
- AI music generation (Suno, Mubert)
- Real-time co-writing interface
- Multi-language support
- Emotional tone detection
- Animation tool integration (RunwayML)
- Advanced reinforcement learning
- Social sharing features

## Development

Built as an MVP for demonstrating autonomous multi-agent story generation. All agents are deterministic and can be extended with actual AI models (GPT-5, Claude, etc.) for production use.

The current implementation focuses on architecture, workflow, and data persistence to prove the concept works end-to-end.
