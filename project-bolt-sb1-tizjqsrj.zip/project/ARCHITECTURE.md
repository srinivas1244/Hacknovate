# StoryWeaver AI - System Architecture

## Overview

StoryWeaver AI is a multi-agent autonomous story generation system that coordinates 5 specialized AI agents to create complete cinematic narratives from simple text prompts.

## Agent Workflow

```
User Prompt → Story Director → Character Agent → Scene Agent → Music Agent → Script Agent → Final Story
                    ↓              ↓                 ↓             ↓              ↓
                Database      Database          Database      Database       Database
                    ↓              ↓                 ↓             ↓              ↓
                                    Feedback Agent (learns from ratings)
```

## Agent Responsibilities

### 1. Story Director Agent (`storyDirector.ts`)

**Role**: Orchestration and high-level planning

**Inputs**:
- User prompt
- Preferences (genre, tone, duration, visual style)

**Process**:
- Analyzes prompt and extracts core narrative
- Creates 4-act story structure (exposition, conflict, climax, resolution)
- Extracts themes and emotional arcs
- Determines optimal character and scene counts
- Generates story title

**Outputs**:
- `StoryOutline` with structure, themes, and planning data

### 2. Character Agent (`characterAgent.ts`)

**Role**: Character design and personality development

**Inputs**:
- Story outline
- Original prompt
- Character count requirement

**Process**:
- Creates protagonist with goals and personality
- Designs antagonist with opposing motivations
- Generates supporting characters (allies, mentors)
- Defines visual descriptions
- Sets dialogue tones and speaking patterns

**Outputs**:
- Array of `CharacterProfile` objects with full personalities

### 3. Scene Agent (`sceneAgent.ts`)

**Role**: Cinematic scene construction and visual storytelling

**Inputs**:
- Story outline
- Character profiles
- Scene count
- Tone and visual style

**Process**:
- Maps story structure to individual scenes
- Generates locations and settings
- Creates visual prompts for image generation
- Writes scene descriptions and action
- Generates dialogue for each scene
- Sets mood, time of day, and atmosphere

**Outputs**:
- Array of `SceneData` objects with complete scene information

### 4. Music Agent (`musicAgent.ts`)

**Role**: Soundtrack composition and emotional scoring

**Inputs**:
- Scene descriptions
- Story tone

**Process**:
- Analyzes scene moods
- Determines appropriate tempo (slow/medium/fast)
- Selects instrumentation
- Creates music generation prompts
- Matches emotional beats to narrative

**Outputs**:
- Array of `MusicCueData` objects with composition instructions

### 5. Script Agent (`scriptAgent.ts`)

**Role**: Final assembly and formatting

**Inputs**:
- Story outline
- All characters
- All scenes
- All music cues

**Process**:
- Merges all agent outputs
- Formats as screenplay, narrative, or storyboard
- Adds stage directions and visual cues
- Structures dialogue properly
- Creates cohesive final product

**Outputs**:
- Formatted script string in chosen format

## Orchestrator (`orchestrator.ts`)

The `StoryOrchestrator` class manages the entire generation pipeline:

1. Initializes all agents
2. Calls agents in correct sequence
3. Manages database persistence
4. Logs agent execution times
5. Reports progress to UI
6. Handles errors and rollback

## Database Schema

### Core Tables

**stories**: Main story records
- Tracks generation status
- Stores metadata (genre, tone, duration)
- Links to all related data

**story_structure**: 4-act structure
- Exposition, conflict, climax, resolution
- Narrative arc details

**characters**: Character profiles
- Personality, goals, visual descriptions
- Dialogue tones and roles

**scenes**: Scene-by-scene breakdown
- Location, time, mood
- Descriptions and dialogue
- Visual prompts for image generation

**music_cues**: Soundtrack information
- Mood, tempo, instruments
- Generation prompts

**scripts**: Final output
- Complete formatted screenplay
- Version tracking

### Supporting Tables

**users**: User accounts
**user_preferences**: Learning data
**feedback**: Ratings and reactions
**agent_logs**: Performance monitoring

## Data Flow

### Generation Flow

```
1. User Input
   ↓
2. Create Story Record (status: generating)
   ↓
3. Story Director → Save Structure
   ↓
4. Character Agent → Save Characters
   ↓
5. Scene Agent → Save Scenes
   ↓
6. Music Agent → Save Music Cues
   ↓
7. Script Agent → Save Final Script
   ↓
8. Update Story Status (status: completed)
   ↓
9. Return Story ID to UI
```

### Viewing Flow

```
1. Load Story
   ↓
2. Parallel Queries:
   - Story metadata
   - Characters
   - Scenes
   - Script
   - Music cues
   ↓
3. Render in tabs
   ↓
4. User can rate/provide feedback
```

## UI Components

### StoryGenerator (`StoryGenerator.tsx`)

- Prompt input
- Preference selection (genre, tone, duration, visual style)
- Example prompts
- Real-time generation progress
- Generate button with loading states

### StoryViewer (`StoryViewer.tsx`)

- Tabbed interface (Script, Scenes, Characters, Music)
- Star rating system
- Detailed view of all story elements
- Back navigation

### StoryLibrary (`StoryLibrary.tsx`)

- Grid of user's stories
- Status indicators
- Delete functionality
- Click to view

## Extensibility

### Adding AI Integration

The current system uses deterministic logic. To integrate real AI:

1. Replace agent methods with API calls to GPT-5/Claude
2. Keep the same interfaces and data structures
3. Add streaming for real-time updates
4. Implement retry logic and error handling

### Adding Image Generation

```typescript
// In Scene Agent
const imageUrl = await generateImage(scene.visual_prompt);
scene.image_url = imageUrl;
```

### Adding Music Generation

```typescript
// In Music Agent
const audioUrl = await generateMusic(cue.prompt);
cue.audio_url = audioUrl;
```

## Performance

- Agent execution logged in `agent_logs`
- Average generation time: ~2-3 seconds (deterministic)
- With AI: ~30-60 seconds estimated
- Parallel agent execution possible for some tasks

## Security

- Row Level Security (RLS) on all tables
- Users can only access their own data
- Input sanitization
- No sensitive data in prompts

## Future Enhancements

1. **Real AI Integration**: GPT-5, Claude 3 for intelligent generation
2. **Image Generation**: DALL-E 3, Stable Diffusion
3. **Music Generation**: Suno, Mubert, ElevenLabs
4. **Co-writing Mode**: Real-time collaboration with AI
5. **Reinforcement Learning**: Learn from aggregate user feedback
6. **Multi-language**: Support multiple languages
7. **Export Options**: PDF, video, animation
8. **Sharing**: Public story gallery
